import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import DaoLayer.H2Repository;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
public class ChatLogServiceImpl implements ChatLogService{


  @Autowired
  H2Repository repository;

  @Override
  public Mono <Object> addData(String user, Map <String, Object> headers , Map<String, Object> params , Object body) {
     return repository.saveData (user,headers,params,body);
  }


  @Override
  public Mono<Object> getData(String user, Map <String, Object> headers , Map<String, Object> params) {
    return repository.getData (user,headers,params);
  }
}
