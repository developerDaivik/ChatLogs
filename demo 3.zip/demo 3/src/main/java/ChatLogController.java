import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/chatlogs")
@RequiredArgsConstructor
public class ChatLogController {

  private ChatLogService chatLogService;

  @PostMapping("/{user}/")
  public Mono <Object> addData(
      @PathVariable(value = "user") String user,
      @RequestHeader Map <String, Object> headers,
      @RequestParam Map<String, Object> params,
      @RequestBody Object body
  ){
    return chatLogService.addData (user,headers,params,body);
  }
  
  
  @GetMapping("/{user}/")
  public Mono<Object> getData(
      @PathVariable(value = "user") String user,
      @RequestHeader Map <String, Object> headers,
      @RequestParam Map<String, Object> params
  ) {
    return chatLogService.getData (user,headers,params);
  }



}
