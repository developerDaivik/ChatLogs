package DaoLayer;

import java.util.Map;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public  class H2Repository  extends CrudRepository<MessageInfo, Long>{


  public Mono <Object> saveData(String user, Map <String, Object> headers , Map<String, Object> params , Object body) {
    // logic to save
    String message = (String) params.getOrDefault ("message","");
    long timeStamp = System.currentTimeMillis();
    // add to db
    return Mono.just (timeStamp);

  }


  public Mono<Object> getData(String user, Map <String, Object> headers , Map<String, Object> params) {
    int limit = (int) params.getOrDefault ("limit",10);
    long start = (long) params.getOrDefault ("start",0);

    //logic to get data from db
    return Mono.just (new Object ());

  }
}
