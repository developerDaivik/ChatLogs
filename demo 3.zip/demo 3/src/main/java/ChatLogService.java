import java.util.Map;

import reactor.core.publisher.Mono;

public interface ChatLogService {

  public Mono<Object> addData(String user, Map <String, Object> headers , Map<String, Object> params , Object body);
  public Mono<Object> getData(String user, Map <String, Object> headers , Map<String, Object> params );
}
